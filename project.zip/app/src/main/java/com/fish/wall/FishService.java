package com.fish.wall;

import android.Manifest;
import android.app.Presentation;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.audiofx.Visualizer;
import android.service.wallpaper.WallpaperService;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import android.webkit.WebView;

public class FishService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new FishEngine(); }

    class FishEngine extends Engine {
        private VirtualDisplay display;
        private Presentation screen;
        private WebView web;
        private Visualizer vis;

        @Override public void onCreate(SurfaceHolder h) {
            super.onCreate(h);
            setTouchEventsEnabled(true);
        }

        @Override public void onSurfaceChanged(SurfaceHolder h, int format, int w, int height) {
            super.onSurfaceChanged(h, format, w, height);
            close();
            DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            display = dm.createVirtualDisplay("fish", w, height, getResources().getDisplayMetrics().densityDpi,
                    h.getSurface(), DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
            screen = new Presentation(FishService.this, display.getDisplay());
            screen.getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            web = new WebView(screen.getContext());
            web.getSettings().setJavaScriptEnabled(true);
            web.loadUrl("file:///android_asset/index.html");
            screen.setContentView(web);
            screen.show();
            if (isVisible()) listen();
        }

        @Override public void onTouchEvent(MotionEvent e) {
            if (web != null) web.dispatchTouchEvent(e);
        }

        @Override public void onVisibilityChanged(boolean visible) {
            if (visible) {
                if (web != null) web.onResume();
                listen();
            } else {
                deaf();
                if (web != null) web.onPause();
            }
        }

        private void listen() {
            if (vis != null || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
            try {
                vis = new Visualizer(0);
                vis.setEnabled(false);
                vis.setCaptureSize(Math.max(256, Visualizer.getCaptureSizeRange()[0]));
                vis.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                    @Override public void onWaveFormDataCapture(Visualizer v, byte[] wave, int rate) { }
                    @Override public void onFftDataCapture(Visualizer v, byte[] fft, int rate) {
                        if (web == null) return;
                        StringBuilder s = new StringBuilder("window.nativeAudio&&nativeAudio([");
                        for (int i = 1; i <= 48 && 2 * i + 1 < fft.length; i++) {
                            int m = (int) Math.min(255, Math.hypot(fft[2 * i], fft[2 * i + 1]) * 3);
                            s.append(m).append(',');
                        }
                        web.evaluateJavascript(s.append("0])").toString(), null);
                    }
                }, Math.min(20000, Visualizer.getMaxCaptureRate()), false, true);
                vis.setEnabled(true);
            } catch (Exception e) {
                Log.e("Fish", "audio unavailable", e);
                deaf();
            }
        }

        private void deaf() {
            if (vis != null) { vis.release(); vis = null; }
        }

        private void close() {
            deaf();
            if (screen != null) { screen.dismiss(); screen = null; }
            if (web != null) { web.destroy(); web = null; }
            if (display != null) { display.release(); display = null; }
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder h) {
            close();
            super.onSurfaceDestroyed(h);
        }
    }
}
